/** 
 *  @module  imf-mm-api-server
 *  @author 
 */
var Koa = require('koa');

module.exports.init = function (option) {
    var server = new Koa();

    var assets = require('./api-assets.js');
    var scan = require('./api-scan.js');
    var dbg_logger = require('./dbg-logger')

    server
        .use(assets.routes())
        .use(scan.routes())
        .use(dbg_logger)

        return server
}