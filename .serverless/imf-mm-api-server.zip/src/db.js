/** @module database
 * 
 * Provide an adapter for different databases
 */

var config = require('config')

var db

switch (config.database) {
    case "local":
        db = require('./db-local')
        break
    case "aws-simple-db":
    default:
        db = require('./db-aws-simpledb')
}

//provide any initialisation functions needed
db.init()

// export each method manually to help auto-complete
// functions in IDE editors

//module.exports.init = db.init
module.exports.info = db.info
module.exports.post = db.post
module.exports.get = db.get