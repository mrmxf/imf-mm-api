/** @module dbg_logger
 * 
 * allows some extra context to be added to a body for debugging purposes
 * **DO NOT USE IN PRODUCTION **
 */
var config = require('config')
var util = require('util')

module.exports = async function (ctx, next) {
  let authors = ""
  try {
    authors= config.app_authors.join(',')
  } catch (e) {
    authors= 'unknown'
  }
  let msg = {}
  msg.node_env = process.env.NODE_ENV
  msg.prefix = config.prefix
  msg.app = `${config.app_name} v${config.app_version} by ${authors}`
  msg.href = ctx.request.href
  msg.fragments = `${ctx.request.method} + ${ctx.request.origin} + ${ctx.request.originalUrl}`
  msg.status = ctx.status
  msg._matchedRoute = ctx._matchedRoute
  msg.database = config.database
  //iterate over all elements of the config array and select the outputs we want
  msg.configs = config.util.getConfigSources().map(config_file => {
    return {
      "name": config_file.name,
      "port": config_file.parsed.port,
      "database": config_file.parsed.database,
      "prefix": config_file.parsed.prefix,
    }
  })

  if (undefined == ctx.body) {
    if (404 == ctx.status) {
      ctx.body = "404 not found"
    } else {
      ctx.body = "ctx.body was undefined."
    }
  }
  ctx.body += `\n------------------------------------------------------------------------------------\n${util.inspect(msg)}`
  await next()
}