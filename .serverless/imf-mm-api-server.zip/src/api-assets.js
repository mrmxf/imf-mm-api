const config = require('config')

const Router = require('koa-router');
const router = Router({
  prefix: `/assets`,
}); //Prefix all routes with /assets

//get our database
const db = require('./db')
const dbtk = require('./db-toolkit')

const not_implemented = async function (ctx, next) {
  ctx.status = 501
  ctx.set('Content-Type', 'text/plain')
  ctx.body = `imf-mm-api functionality not Implemented yet. Come back later.`
  // don't fire the next event. We're done
  await next()
}

const get_assets = async function (ctx, next) {
  // asynchronously fetch the first page from the database
  let assets = await db.get(config.get['default_get_limit'])

  //format the results according to the API spec
  let api_response = dbtk.asset_TO_api_get_results(assets)

  //massage teh response
  ctx.status = 200
  ctx.set('Content-Type', 'application/json')
  ctx.body = JSON.stringify(api_response)

  //pass response to the next middleware
  await next()
}

const get_assets_by_id = async function (ctx, next) {
  // asynchronously fetch the first page from the database
  let assets = await db.get(config.get['default_get_limit'])

  //format the results according to the API spec
  let api_response = dbtk.asset_TO_api_get_results(assets)

  //massage the response
  ctx.status = 200
  ctx.set('Content-Type', 'application/json')
  ctx.body = JSON.stringify(api_response)

  ctx.status = 200
  ctx.body = `No assets for id:${ctx.params.id}`
  // don't fire the next event. We're done
  await next()
}

router.get('/', get_assets)
router.put('/:id', not_implemented)
router.post('/:id', not_implemented)
router.delete('/:id', not_implemented)
router.get('/1234/:id', get_assets_by_id)
router.get('/:id([0-9A-Za-z\-]{3,})', get_assets_by_id)
//router.get('/:id([0-9]*)', get_assets_by_id)

console.log(`assets initialised`)

module.exports = router;