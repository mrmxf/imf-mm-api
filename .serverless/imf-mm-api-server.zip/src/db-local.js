/** @module local database
 * 
 * it's dumb, it's not intended for production but it works
 * it WILL have problems if db.json gets bigger thatn 100MB
  */
const low = require('lowdb')
const FileSync = require('lowdb/adapters/FileSync')
 
const adapter = new FileSync('db.json')
const db = low(adapter)
 
// Set some defaults
db.read()
db.defaults({ assets: [], requests: [] })

module.exports.get_asset = function(asset_id){
    var record = db.get('assets')
        .find({id:asset_id})
        .value()

    if (undefined == record) {
        return record = db.get('assets')
            .find({manifest:asset_id})
            .value()
    }
    return record
}