//config management load order described here: https://github.com/lorenwest/node-config/wiki/Configuration-Files
//NODE_ENV legal values: development, staging, beta, production
//see README.md for how to set this
const config = require('config')

//load the server library
const server = require('./imf-mm-api-server').init()
process.env.NODE_ENV = 'staging'

//start the server
console.log(`Listening on port ${config.get('port')}`)
server.listen({
    "port": config.get('port')
})