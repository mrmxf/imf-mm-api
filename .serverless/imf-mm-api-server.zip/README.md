# imf-mm-api-server-js
A node server to implement the IMF Media Management API with a choice of databases

## installation

* install node 8.10 or above
* install serverless framework globally `npm install --global serverless`
* install gulp-cli globally `npm install --global gulp-cli`
* [possibly make](https://serverless.com/framework/docs/providers/aws/guide/credentials/#aws---credentials)
  and configure [aws credentials](https://serverless.com/framework/docs/providers/aws/cli-reference/config-credentials/)
* update [serverless.yml](https://serverless.com/framework/docs/providers/aws/guide/serverless.yml/)
* Execution
  * local: configure `/.vscode/runtime.env` to set `NODE_ENV`
  * lambda: edit `serverless.yml` to set `NODE_ENV` for the cloudformation deployed app

## AWS requirements

All AWS credentials are taken from environment variables - it's up to you to make them right before
executing the demo server if you're going to use the AWS facilities of the demo.

* AWS_ACCESS_KEY_ID
* AWS_SECRET_ACCESS_KEY

Region information is stored in the config files. The following permissions are needed if you're going
to replicate the s3 bucket storage and replicated the SimpleDB back end:

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "VisualEditor0",
            "Effect": "Allow",
            "Action": [
                "s3:ListBucketByTags",
                "s3:GetBucketTagging",
                "s3:GetObjectVersionTagging",
                "s3:ListBucketVersions",
                "s3:GetBucketLogging",
                "s3:ListBucket",
                "s3:GetObjectTagging",
                "s3:ListBucketMultipartUploads",
                "s3:GetBucketWebsite",
                "s3:GetBucketNotification",
                "s3:GetObjectVersionForReplication",
                "s3:GetBucketLocation",
                "s3:GetObjectVersion",
                "s3:GetAccountPublicAccessBlock",
                "s3:ListAllMyBuckets",
                "s3:HeadBucket"
            ],
            "Resource": [
                "arn:aws:s3:::*/*",
                "arn:aws:s3:::imf-mm-api-media"
            ]
        },
        {
            "Sid": "VisualEditor0",
            "Effect": "Allow",
            "Action": "sdb:ListDomains",
            "Resource": "*"
        },
        {
            "Sid": "VisualEditor1",
            "Effect": "Allow",
            "Action": "sdb:*",
            "Resource": "arn:aws:sdb:eu-east-2:*:domain/myDomainName"
        }
    ]
}
```