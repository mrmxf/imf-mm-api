/** SimpleDb storage tester
 *
 */
var imf_simpledb = require('../src/db-aws-simpledb')

const test_asset1 = {
    //owner of this record
    user: {
        id: "usr-10000001",
        name: "mrmxf",
    },
    aws: {
        Key: "media/bs500/dalet-ov/video.mxf",
        ETag: "40219u898",
        LastModified: "daet",
        StorageClasss: "STANDARD",
    },
    identifiers: [
        "urn:uuid:d2a8e02d-c9ca-45a8-956b-ed19c29ea7ec",
        "urn:sha1:EYdxJm+XweMzO+JrHjphObvKwGI=",
    ],
    locations: {
        locationProviderId: "Mr MXF Jest Data",
        locationList: [
            "nowhere",
            "C:\\windows\\path\\example.mxf",
            "\\\\unc\\mount\\path\\example\\location.mxf",
            "/mnt/media/linux/file.mxf",
            "http://imf-mm-api.cloud/media/bs500/dalet-ov/video.mxf",
        ],
    },
    file_size: 1234568,
    file_type: "appplication/mxf",
    "$$ref": "",
}
const test_asset2 = {
    //owner of this record
    user: {
        id: "usr-10000002",
        name: "mrmxf-dev",
    },
    aws: {
        Key: "bs500/dalet-a-ov/PKL_aaaccae8-6042-4a45-85b0-5daa71d98618.xml",
        ETag: "8cd313201700f509b3e5da08ebe5d916",
        LastModified: "Mar 22, 2019 11:05:48 PM GMT+0000",
        StorageClasss: "STANDARD",
    },
    identifiers: [
        "urn:uuid:aaaccae8-6042-4a45-85b0-5daa71d98618",
        "urn:sha1:nxhXNSjNWpkxg/RonzslcG1vsH0=",
    ],
    locations: {
        locationProviderId: "Mr MXF Jest Data",
        locationList: [
            "PKL_aaaccae8-6042-4a45-85b0-5daa71d98618.xml",
            "C:\\windows\\path\\PKL_aaaccae8-6042-4a45-85b0-5daa71d98618.xml",
            "\\\\unc\\mount\\path\\example\\PKL_aaaccae8-6042-4a45-85b0-5daa71d98618.xml",
            "/mnt/media/linux/PKL_aaaccae8-6042-4a45-85b0-5daa71d98618.xml",
            "https://s3.us-east-2.amazonaws.com/imf-mm-api-media/bs500/dalet-a-ov/PKL_aaaccae8-6042-4a45-85b0-5daa71d98618.xml",
        ],
    },
    file_size: 7324,
    file_type: "pkl",
    "$$ref": "",
}


var start_output = "\n\n\n-------------------------------------------------------------------------\n"
var params = {
    domain_name: 'a-new-db-with-a-unique-name',
}
var error_params = {
    domain_name: 'a-non-existant-domain',
}

describe(`${start_output}Validating simple db code`, () => {

    describe('Database basics', () => {

        test('rejects a promise if the dB does not exist', () => {
            return imf_simpledb.info(error_params)
                .catch(e =>
                    expect(e).toMatch(/No such Database(.*)/)
                )
        })

        test('init a dB', () => {
            return imf_simpledb.init(params)
                .then(data => {
                    expect(data).toEqual('ok')
                })
        })

        test('returns metadata if the dB exists', () => {
            return imf_simpledb.info(params)
                .then(data => {
                    expect(data.domain_name).toEqual(params.domain_name)
                })
        })

        test('add test_asset1 to a new dB', () => {
            return imf_simpledb.post(test_asset1)
                .then(data => {
                    expect(data).toEqual('ok')
                })
        })

        test('add test_asset2 to a new dB', () => {
            return imf_simpledb.post(test_asset2)
                .then(data => {
                    expect(data).toEqual('ok')
                })
        })

        test('get all assets from dB', () => {
            return imf_simpledb.get(100)
                .then(data => {
                    expect(data.length).toEqual(2)
                })
        })
    })

})